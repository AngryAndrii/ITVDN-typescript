import { EmailValidator } from '03-export-statement';

const x: EmailValidator = new EmailValidator();
